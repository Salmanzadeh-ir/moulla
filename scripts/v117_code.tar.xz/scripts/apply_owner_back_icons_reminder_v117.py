#!/usr/bin/env python3
"""Owner-only v117 changes: unify visible Back, replace two learning logos, move reminders from About to Wisdom."""
from pathlib import Path
import re

p=Path('app/src/main/assets/index.html')
s=p.read_text(encoding='utf-8')
def one(old,new,label):
    global s
    n=s.count(old)
    assert n==1, f'{label}: expected once, found {n}'
    s=s.replace(old,new,1)

# Replace ONLY the two v116 art nodes; their routes and names must be retained.
for key,name in [('tawhid','tawhid'),('see_god','kaaba')]:
    pattern=r'(<button type="button" class="home-menu-card home-submenu-card" data-menu="'+key+r'"[^>]*>\s*)(<span class="home-menu-icon-wrap is-devotional"[^>]*>.*?</svg></span>)'
    replacement=r'\1<span class="home-menu-icon-wrap is-devotional" aria-hidden="true"><img class="home-menu-icon devotional-logo" src="images/pmm_v117_'+name+'_logo.png" alt="" loading="eager" decoding="sync"></span>'
    s,n=re.subn(pattern,replacement,s,count=1,flags=re.DOTALL)
    assert n==1, (key,n)

# Remove Reminder from About, retain Biography, Contact, and existing gallery.
one('      <button class="about-entry" type="button" id="about-reminder"><span class="about-entry-icon">♧</span><span>تنظیم یادآور مهمانی مولا</span></button>\n','', 'remove About reminder control')
one("  document.getElementById('about-reminder').addEventListener('click',renderReminderSettings);\n",'', 'remove obsolete About handler')

# Place a settings control in the wisdom view, always visible during introduction, draw, result.
one('''    <div class="wisdom-body">
      
      <section id="wisdom-intro"''','''    <div class="wisdom-body">
      <div class="wisdom-settings-entry"><button type="button" id="wisdom-reminder-gear" class="wisdom-settings-gear" title="تنظیمات یادآوری" aria-label="تنظیم یادآور مهمانی مولا" aria-controls="wisdom-reminder-panel" aria-expanded="false"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="1.85" stroke-linecap="round" stroke-linejoin="round"><path d="M10 2h4l.6 2.4c.5.2 1 .4 1.4.7l2.3-1.1 2.8 2.8-1.1 2.3c.3.4.5.9.7 1.4L23 11v4l-2.4.6c-.2.5-.4 1-.7 1.4l1.1 2.3-2.8 2.8-2.3-1.1c-.4.3-.9.5-1.4.7L14 23h-4l-.6-2.4c-.5-.2-1-.4-1.4-.7l-2.3 1.1-2.8-2.8 1.1-2.3c-.3-.4-.5-.9-.7-1.4L1 14v-4l2.4-.6c.2-.5.4-1 .7-1.4L3 5.7l2.8-2.8 2.3 1.1c.4-.3.9-.5 1.4-.7L10 2Z" transform="translate(1 0) scale(.91)"/><circle cx="12" cy="12" r="3.2"/></svg></button></div>
      <section id="wisdom-reminder-panel" class="pmm-wisdom-reminder-panel" aria-label="تنظیمات یادآوری تفال به نهج‌البلاغه" hidden></section>
      <section id="wisdom-intro"''','insert gear and settings panel')

# Reuse existing native settings implementation, now rendered exclusively into the wisdom panel.
one("function renderReminderSettings(){\n let current={frequency:'daily',consent:false,allowed:false};",'''function renderReminderSettings(){
  const panel=document.getElementById('wisdom-reminder-panel');
  const wisdom=document.getElementById('wisdom-scroll');
  if(!panel||wisdom.hidden)return;
 let current={frequency:'daily',consent:false,allowed:false};''','wisdom settings entry point')
one(" contents.innerHTML='<section class=\"pmm-reminder-settings\" aria-label=\"تنظیم یادآوری مولا\">'+",'''  panel.innerHTML='<section class="pmm-reminder-settings" aria-label="تنظیم یادآوری مولا">'+''','render reminder in wisdom instead of About')
one(" '<button type=\"button\" id=\"pmm-reminder-back\">بازگشت به درباره ما</button></div></section>';",''' '<button type="button" id="pmm-reminder-back">بازگشت به تفال</button></div></section>';
  panel.hidden=false;
  wisdom.classList.add('reminder-open');
  document.getElementById('wisdom-reminder-gear').setAttribute('aria-expanded','true');
  wisdom.scrollTop=0;''','settings back target')
one(" document.getElementById('pmm-reminder-back').addEventListener('click',renderAbout);\n}",'''  document.getElementById('pmm-reminder-back').addEventListener('click',closeWisdomReminderSettings);
}
function closeWisdomReminderSettings(){
  const panel=document.getElementById('wisdom-reminder-panel');
  panel.hidden=true;
  document.getElementById('wisdom-scroll').classList.remove('reminder-open');
  document.getElementById('wisdom-reminder-gear').setAttribute('aria-expanded','false');
  document.getElementById('wisdom-scroll').scrollTop=0;
}
document.getElementById('wisdom-reminder-gear').addEventListener('click',()=>{
  if(document.getElementById('wisdom-reminder-panel').hidden)renderReminderSettings();
  else closeWisdomReminderSettings();
});''','close settings to wisdom, gear event')

# Photo gallery is opened from Media; Back from its overview must restore Media submenu.
one("   window.PMM_NEW_UI.closeGallery();screen='home';return;","   window.PMM_NEW_UI.closeGallery();screen='home';window.PMM_NEW_UI.openSubmenu('media');return;",'gallery back restores Media parent')

# A top Back click and Android hardware Back must close the settings, not navigate Home.
one('''goBack=function(){
 // Back inside a home submenu returns to the six-item root before leaving Home.''','''goBack=function(){
  // A nested reminder screen returns to the same Wisdom draw/result, not Home.
  if(screen==='wisdom'&&!document.getElementById('wisdom-reminder-panel').hidden){closeWisdomReminderSettings();return;}
 // Back inside a home submenu returns to the six-item root before leaving Home.''', 'wisdom settings navigation')
# Ensure returning to wisdom later never shows a stale open settings state.
one('''function enterWisdom(){
  originalFocus=document.activeElement;''','''function enterWisdom(){
   closeWisdomReminderSettings();
  originalFocus=document.activeElement;''', 'reset wisdom gear on entry')

# One reference PNG and location for all visible top-level Back controls, including the Home-submenu Back.
css='''/* v117: unified Back appearance, hit area, location and native navigation target.
   Exact approved Nahj image is used; page-specific routing stays in goBack(). */
#scene #back-top, #stage #legacy-back-top, #scene #exit.is-submenu-back {
  position:absolute!important;left:78.65%!important;right:auto!important;
  top:33.54%!important;width:11.75%!important;height:auto!important;
  aspect-ratio:1/1!important;min-height:0!important;max-height:none!important;
  border:0!important;border-radius:0!important;box-shadow:none!important;
  background:transparent url("images/back_v1043_approved.png") center/contain no-repeat!important;
  color:transparent!important;font-size:0!important;text-shadow:none!important;
  padding:0!important;display:block!important;z-index:100!important;
  cursor:pointer;pointer-events:auto!important;touch-action:manipulation!important;
}
#scene #back-top[hidden],#stage #legacy-back-top[hidden]{display:none!important}
#scene #back-top::before,#scene #back-top::after,
#stage #legacy-back-top::before,#stage #legacy-back-top::after,
#scene #exit.is-submenu-back::before,#scene #exit.is-submenu-back::after{
  display:none!important;content:none!important;background:none!important;
}
#scene #back-top:active,#stage #legacy-back-top:active,#scene #exit.is-submenu-back:active{
  transform:scale(.94)!important;filter:brightness(1.08)!important;
}
#scene #back-top:focus-visible,#stage #legacy-back-top:focus-visible,#scene #exit.is-submenu-back:focus-visible{
  outline:3px solid #f8d16c!important;outline-offset:3px!important;
}
/* No second Back action under course toolbar; the standard top Back handles nested route. */
#offline-course-scroll .course-note-list-heading #course-notes-back{display:none!important}
/* Two high-resolution owner-requested logos, integrated into the existing gold-blue cards. */
#scene .home-submenu-card .home-menu-icon-wrap.is-devotional{
  border:0!important;background:transparent!important;box-shadow:none!important;
  width:clamp(70px,11cqw,100px)!important;height:clamp(70px,11cqw,100px)!important;
  flex-basis:clamp(70px,11cqw,100px)!important;
}
#scene .home-submenu-card .home-menu-icon.devotional-logo{
  display:block;width:100%!important;height:100%!important;object-fit:contain;
  filter:drop-shadow(0 2px 2px rgba(95,64,19,.19));
}
/* Gear lives in Tafal view, not About. Preserve the existing native permission and frequency functions. */
#wisdom-scroll .wisdom-settings-entry{display:flex;justify-content:flex-start;direction:rtl;margin:0 1% 2%;min-height:43px}
#wisdom-scroll .wisdom-settings-gear{
  width:43px;height:43px;min-width:43px;display:grid;place-items:center;
  background:linear-gradient(140deg,#fff8db,#eac671);border:2px solid #b7862b;
  border-radius:12px;color:#073e78;box-shadow:0 2px 5px #79603940;cursor:pointer;
}
#wisdom-scroll .wisdom-settings-gear svg{width:26px;height:26px;display:block}
#wisdom-scroll .wisdom-settings-gear:focus-visible{outline:3px solid #094f8f;outline-offset:2px}
#wisdom-scroll.reminder-open #wisdom-intro,
#wisdom-scroll.reminder-open #wisdom-drawing,
#wisdom-scroll.reminder-open #wisdom-result{display:none!important}
#wisdom-scroll .pmm-wisdom-reminder-panel[hidden]{display:none!important}
#wisdom-scroll .pmm-reminder-settings{background:linear-gradient(#fff8df,#f3d89a);color:#153f63;
 border:2px solid #a87835;border-radius:16px;padding:14px 12px;margin:5px 1% 16px;
 direction:rtl;line-height:1.8;font-family:'PMM Sahel SemiBold',Tahoma,sans-serif!important}
#wisdom-scroll .pmm-reminder-settings h2{font-size:clamp(16px,3.2cqw,22px);font-weight:900;margin:0 0 8px}
#wisdom-scroll .pmm-reminder-settings label{display:block;font-weight:900;margin:10px 0 5px}
#wisdom-scroll .pmm-reminder-settings select{display:block;width:100%;min-height:46px;border:2px solid #b88936;
 border-radius:10px;padding:7px;background:#fff9ec;color:#073e78;direction:rtl}
#wisdom-scroll .pmm-reminder-settings .pmm-reminder-note{margin:8px 0;font-size:clamp(12px,2.45cqw,16px);line-height:1.8}
#wisdom-scroll .pmm-reminder-settings .pmm-reminder-actions{display:grid;gap:8px;margin-top:12px}
#wisdom-scroll .pmm-reminder-settings button{min-height:43px;border-radius:10px;border:2px solid #bd954e;
 background:#0a4577;color:#ffedc3;font-weight:800;font-family:'PMM Sahel SemiBold',Tahoma,sans-serif!important}
#wisdom-scroll .pmm-reminder-settings select:focus-visible,#wisdom-scroll .pmm-reminder-settings button:focus-visible{
 outline:3px solid #0c79b6;outline-offset:2px}
'''
# Place CSS as final override immediately before the main style tag ending. This stylesheet contains v116 icons earlier.
style_end='</style>\n<link rel="stylesheet" href="pmm_online_updates.css">'
one(style_end,css+'</style>\n<link rel="stylesheet" href="pmm_online_updates.css">','inject v117 CSS final override')
p.write_text(s,encoding='utf-8')
# Only copy two new artwork files; all other app bytes unchanged.
for key in ('tawhid','kaaba'):
    target=Path('app/src/main/assets/images/pmm_v117_'+key+'_logo.png')
    src=Path('scripts/v117_'+key+'_logo.png')
    assert src.exists(),f'Missing generated {src}'
    target.write_bytes(src.read_bytes())
print('PASS: v117 Back reference, new Allah/Kaaba artwork and Tafal-only reminder settings applied')
