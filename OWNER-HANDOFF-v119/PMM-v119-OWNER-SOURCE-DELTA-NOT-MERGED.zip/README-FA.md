# بسته پیشنهادی v119 — اصلاح یادآور تفأل و دوره آفلاین

**وضعیت: کدنویسی و آزمون‌های آفلاین انجام شده؛ این بسته هنوز در GitHub اعمال نشده و APK جدید ساخته نشده است.**

مرجع دقیق سورس تاییدشده فعلی: `main@0fce031b91ffd90893482dba664a8bd0704fac98`.
منبع دو فایل وب از APK موفق v118 استخراج و Git blob SHA-1 آنها با مخزن مطابقت داده شده است.

## ۱. یادآور تفأل

- هنگام نخستین ورود، اجازه یادآوری درخواست می‌شود؛ در Android 13+ از مجوز واقعی سیستم `POST_NOTIFICATIONS` و در Android 12 یا قدیمی‌تر، که چنین پنجره سیستمی‌ای وجود ندارد، از گفت‌وگوی رضایت صریح داخل برنامه استفاده می‌شود.
- رد مجوز، اعلان را فعال نمی‌کند. تأیید مجوز/رضایت در حافظه محلی ثبت می‌شود.
- ساعت **اولین تأیید** تا حد دقیقه ذخیره می‌شود؛ تکرار روزانه/هفتگی/ماهانه از همان ساعت محلی پیروی می‌کند.
- تأیید بین ۰۰:۰۰ و ۰۶:۵۹ به ساعت ۰۷:۰۰ منتقل می‌شود. در همان محدوده شبانه حتی اگر سیستم اعلان تأخیری تحویل دهد، ارسال نمی‌شود و به ۰۷:۰۰ موکول می‌شود.
- زمان‌بندی مجدد پس از راه‌اندازی گوشی، تغییر ساعت/منطقه زمانی و به‌روزرسانی برنامه با حفظ تنظیمات انجام می‌شود.
- «اولین یادآوری آزمایشی پنج دقیقه بعد» مربوط به نسخه قبل به نفع زمان‌بندی جدید کنار گذاشته شده است؛ اولین نوبت، نخستین موعد بعد از فعال‌سازی است.

## ۲. دوره آفلاین ۱۰۱۹ صوتی

- کنار انتخاب روزی ۱، روزی ۲ یا هفته‌ای ۱ صوت، ورودی ساعت افزوده شده است.
- همه دقیقه‌ها از ۰۵:۰۰ تا ۲۳:۵۹ معتبرند؛ ۰۰:۰۰ فقط به معنی **نیمه‌شبِ انتهای روز انتخاب‌شده** پذیرفته می‌شود. ۰۰:۰۱ تا ۰۴:۵۹ مردود است.
- اعلان محلی مستقل و بی‌صدا با عنوان دقیق «قرار امروز، پای منبر مولا» ثبت می‌شود.
- در حالت روزانه، روزی یک اعلان در ساعت انتخابی؛ در حالت هفتگی، یک اعلان در روز هفته انتخابی ارسال می‌شود.
- کلیک روی اعلان، **صفحه دوره** را باز می‌کند، اما دانلود MP3 فقط با Play کاربر شروع می‌شود.
- برنامه، یادداشت‌ها، جای شنیدن و شرط دوسوم شنیدن دست‌نخورده می‌مانند.
- برنامه‌های قدیمی فاقد ساعت به‌طور خودکار ساعت دلخواه جدید دریافت نمی‌کنند؛ کاربر باید برنامه دوره را باز و ساعت را تأیید کند.
- پس از تکمیل هر ۱۰۱۹ صوت، یادآوری دوره لغو می‌شود.

## ۳. حفاظت و محدودیت‌ها

- اعلان‌ها **محلی و بدون سرور یا نیاز به اینترنت** هستند. دریافت خودکار صوت اضافه نمی‌شود.
- برای حفظ باتری و رعایت سیاست اندروید از `AlarmManager.setAndAllowWhileIdle` استفاده شده است. زمان نمایش دقیقه‌به‌دقیقه تضمین‌شدنی نیست؛ Android/Doze/OEM ممکن است آن را به تأخیر بیندازند.
- بدون تأیید کاربر یا در صورت بستن اعلان‌ها از تنظیمات دستگاه هیچ برنامه‌ای حق فعال‌سازی اجباری آنها را ندارد.
- امضای رسمی، `app/build.gradle`، نسخه بازار و قفل تاریخی v118 نباید تغییر کنند.
- این بسته برای **شاخه آزمایشی جدید** است؛ پس از تست ساخت APK، قفل ۱۸۲ فایل v119 و آزمون CI، ادغام نیازمند بررسی است.

## ۴. اجرای محلی در یک مخزن سالم

این دستورها فقط در کامپیوتر توسعه‌دهنده‌ای اجرا می‌شوند که دسترسی معتبر به GitHub و Android SDK دارد. ابزار اعمال، هیچ Push، Merge یا انتشار خودکاری انجام نمی‌دهد.

```bash
git clone https://github.com/Salmanzadeh-ir/moulla.git
git -C moulla checkout 0fce031b91ffd90893482dba664a8bd0704fac98
git -C moulla switch -c feature/owner-v119-local-reminders
python3 /path/to/unzipped/scripts/apply_to_checkout.py /path/to/moulla
cd moulla
git add app/src/main/assets/index.html app/src/main/assets/pmm_offline_course.js \
  app/src/main/java/ir/nahj/towhidkarbordi/MainActivity.java \
  app/src/main/java/ir/nahj/towhidkarbordi/WisdomReminderScheduler.java \
  app/src/main/java/ir/nahj/towhidkarbordi/WisdomReminderReceiver.java \
  app/src/main/java/ir/nahj/towhidkarbordi/CourseReminderScheduler.java \
  app/src/main/java/ir/nahj/towhidkarbordi/PmmReminderClock.java \
  design/owner-v119-main-app-lock.json design/OWNER_V119_REMINDERS_FA.md \
  scripts/verify_owner_v119_lock.py scripts/TestReminderClock.java \
  scripts/test_course_state_compat.js scripts/test_native_compile.sh \
  .github/workflows/verify-layout-lock.yml AGENTS.md OWNER_LOCK.md
python3 scripts/verify_owner_v119_lock.py
node scripts/test_v16_back_navigation.js
node scripts/test_owner_v118_back_notes.cjs
bash scripts/test_native_compile.sh
node scripts/test_course_state_compat.js
# ساخت آزمایشی در محیط دارای SDK: gradle :app:assembleDebug
```

**نکته:** هنگام اجرای `git add` قفل جدید ۱۸۲ فایل باید بررسی شود. انجام `git push`، ساخت APK و تأیید عملکرد واقعی گوشی هنوز مستقل از این بسته هستند.

## ۵. آزمون‌های انجام‌شده در تهیه این بسته

- کامپایل Java خالص `PmmReminderClock` و اجرای ۱۴ آزمون زمان‌بندی: موفق.
- کامپایل چهار کلاس بومی یادآوری با نمونه‌تعاریف رابط Android: موفق (این آزمون جایگزین کامپایل Android SDK نیست).
- بررسی نحو فایل JS دوره و ۷ بخش JS تعبیه‌شده در HTML: موفق.
- آزمون سازگاری و حفظ یادداشت‌ها، پیشرفت و برنامه قدیمی: موفق.
- آزمون محافظت از ۱۰ جایگزینی محدود `MainActivity.java`: موفق روی ورودی نمونه. هنوز روی فایل واقعی `MainActivity.java` اجرا نشده است.
- **ساخت Android APK، آزمون اعلان روی گوشی و ثبت GitHub: هنوز انجام نشده‌اند.**
