from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
html_path=ROOT/'app/src/main/assets/index.html'
course_path=ROOT/'app/src/main/assets/pmm_offline_course.js'
h=html_path.read_text(encoding='utf-8');s=course_path.read_text(encoding='utf-8')
def swap(text,old,new,name):
 count=text.count(old)
 if count!=1: raise AssertionError(f'{name}: {count} matches')
 return text.replace(old,new,1)
h=swap(h,'        <div class="course-weekdays" id="course-weekdays" hidden>', '''        <div class="course-reminder-setting">
          <label for="course-reminder-time">ساعت یادآوری قرار امروز</label>
          <input type="time" id="course-reminder-time" value="09:00" step="60" required
                 aria-describedby="course-reminder-time-help" aria-label="انتخاب ساعت یادآوری دوره آفلاین">
          <p id="course-reminder-time-help">از ۵:۰۰ صبح تا ۲۳:۵۹؛ یا ۰۰:۰۰ به معنی ۱۲ شب در پایان روز انتخاب‌شده. اعلان فقط در صورت اجازه شما فعال می‌شود.</p>
        </div>
        <div class="course-weekdays" id="course-weekdays" hidden>''','course reminder input')
h=swap(h,'</style>', '''/* v119 owner-requested reminder clock, within the existing course setup card. */
#offline-course-scroll .course-reminder-setting{margin:3% 0;padding:3%;border:1.5px solid #c4933b;
 border-radius:13px;background:#fff7dd;color:#07376f;text-align:right}
#offline-course-scroll .course-reminder-setting label{display:block;margin-bottom:6px;
 font:900 clamp(11px,1.85cqw,16px)/1.7 'PMM Estedad',Tahoma,sans-serif}
#offline-course-scroll #course-reminder-time{display:block;direction:ltr;text-align:center;width:min(100%,170px);
 min-height:44px;box-sizing:border-box;border:2px solid #bb8733;border-radius:9px;
 background:#fffdf3;color:#07376f;font:800 17px/1.4 Tahoma,sans-serif}
#offline-course-scroll .course-reminder-setting p{margin:7px 0 0;
 font:600 clamp(10px,1.5cqw,13px)/1.9 'PMM Estedad',Tahoma,sans-serif}
</style>''','course CSS')
h=swap(h,'''اولین اعلان آزمایشی از ۵ دقیقه پس از اولین ورود زمان‌بندی می‌شود و حتی با بسته بودن برنامه نیز دریافت‌شدنی است. زمان نمایش ممکن است با محدودیت باتری گوشی کمی تأخیر داشته باشد.''','''ساعت تأیید اولیه، مبنای اعلان‌های روزانه، هفتگی یا ماهانه است. در صورت تأیید بین ۱۲ شب و ۷ صبح، ساعت ۷ صبح ملاک می‌شود. اعلان تفأل هرگز از ۰۰:۰۰ تا قبل از ۷:۰۰ نمایش داده نمی‌شود. محدودیت باتری می‌تواند اعلان را با تأخیر نمایش دهد.''','wisdom user text')

s=swap(s,"let state=loadState(),courseOpen=false,draftMode='daily1',draftWeekday=null;", """let state=loadState(),courseOpen=false,draftMode='daily1',draftWeekday=null;
// A new time is required for each newly configured course plan; old plans retain progress without guessing a clock.
const COURSE_REMINDER_TIME=/^(?:00:00|(?:0[5-9]|1[0-9]|2[0-3]):[0-5][0-9])$/;
function validCourseReminderTime(value){return typeof value==='string'&&COURSE_REMINDER_TIME.test(value)}
function syncNativeCourseReminder(){
 const bridge=window.PMMNative;
 if(!bridge||typeof bridge.setCourseReminderSchedule!=='function')return;
 if(state.accepted&&state.plan&&validCourseReminderTime(state.plan.reminderTime)){
  try{bridge.setCourseReminderSchedule(state.plan.mode,state.plan.weekday??-1,state.plan.reminderTime)}catch(_){}
 }
}
""",'time helpers')
s=swap(s,"    baseCompleted:Number.isInteger(raw.plan.baseCompleted)&&raw.plan.baseCompleted>=0?raw.plan.baseCompleted:0};", "    baseCompleted:Number.isInteger(raw.plan.baseCompleted)&&raw.plan.baseCompleted>=0?raw.plan.baseCompleted:0,\n    reminderTime:validCourseReminderTime(raw.plan.reminderTime)?raw.plan.reminderTime:null};", 'plan restore')
s=swap(s," draftWeekday=state.plan?.weekday??null;\n document.querySelectorAll('[data-course-plan]')", " draftWeekday=state.plan?.weekday??null;\n $('course-reminder-time').value=validCourseReminderTime(state.plan?.reminderTime)?state.plan.reminderTime:'09:00';\n document.querySelectorAll('[data-course-plan]')", 'setup restore clock')
s=swap(s,"""$('course-save-plan').addEventListener('click',()=>{
 if(draftMode==='weekly'&&!Number.isInteger(draftWeekday)){showToast('لطفاً روز هفتگی خود را انتخاب کنید.');return;}
 state.plan={mode:draftMode,weekday:draftMode==='weekly'?draftWeekday:null,startDate:todayKey(),baseCompleted:state.completedCount};
 state.extras={};state.pendingAdvance=false;saveState();renderDashboard();
});""", """$('course-save-plan').addEventListener('click',()=>{
 if(draftMode==='weekly'&&!Number.isInteger(draftWeekday)){showToast('لطفاً روز هفتگی خود را انتخاب کنید.');return;}
 const time=$('course-reminder-time').value;
 if(!validCourseReminderTime(time)){
  showToast('ساعت یادآوری باید از ۵ صبح تا ۱۲ شب باشد. فقط ۰۰:۰۰ برای نیمه‌شب مجاز است.');
  $('course-reminder-time').focus();return;
 }
 const priorPlan=state.plan,priorExtras=state.extras,priorAdvance=state.pendingAdvance;
 state.plan={mode:draftMode,weekday:draftMode==='weekly'?draftWeekday:null,
  startDate:todayKey(),baseCompleted:state.completedCount,reminderTime:time};
 state.extras={};state.pendingAdvance=false;
 if(!saveState()){
  state.plan=priorPlan;state.extras=priorExtras;state.pendingAdvance=priorAdvance;
  return;
 }
 syncNativeCourseReminder();
 // On older Android there is no OS-level POST_NOTIFICATIONS runtime dialog.
 // The native bridge uses an explicit app consent dialog on these devices.
 try{
  if(window.PMMNative&&typeof window.PMMNative.getReminderSettings==='function'){
   const status=JSON.parse(window.PMMNative.getReminderSettings());
   if((!status.consent||!status.allowed)&&typeof window.PMMNative.askReminderPermission==='function')
    window.PMMNative.askReminderPermission();
  }
 }catch(_){}
 renderDashboard();
});""", 'schedule on save')
s=swap(s," getTrackCount:()=>tracks.length\n});\n})();", " getTrackCount:()=>tracks.length\n});\n// After app updates/restarts restore the native alarm from the previously user-selected time.\nsyncNativeCourseReminder();\n})();",'update/restart persistence')
for marker in ["logic.canMarkHeard", "releaseNahjInlineStream",'preload="none"']:
    if marker not in (s+h): raise AssertionError('missing frozen invariant '+marker)
html_path.write_text(h,encoding='utf-8');course_path.write_text(s,encoding='utf-8')
print('PASS: one-to-one asset edits, no broad replacement')
