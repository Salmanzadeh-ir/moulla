#!/usr/bin/env python3
"""Owner-approved v119 reminder patch. Offline, fail-closed, no Git pushes.
Run only from a clean checkout at the exact approved v118 main commit.
"""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

from patch_main_activity import patch

PATCH=Path(__file__).resolve().parents[1]
BASE_COMMIT='0fce031b91ffd90893482dba664a8bd0704fac98'
ORIGINAL={
 'app/src/main/assets/index.html':'759056c5b8cb6cad399b1eebf5551106b89b4742',
 'app/src/main/assets/pmm_offline_course.js':'274b15a07e941dba8ea460e17f1aa3cf5d2bc3ba',
 'app/src/main/java/ir/nahj/towhidkarbordi/MainActivity.java':'5a5c71553233f530bfdb72d37eabf01e6448b917',
 'app/src/main/java/ir/nahj/towhidkarbordi/WisdomReminderScheduler.java':'6a1f323814a4aa6eac7e5262d8b1454f966fd229',
 'app/src/main/java/ir/nahj/towhidkarbordi/WisdomReminderReceiver.java':'6d9b34515b6bb7bb24f6e718080d72a61f2bbc49',
 'design/owner-v118-main-app-lock.json':'9eb6a51aa9bf3c839aaff12d254f2e927e9d710e',
}
NEW_JAVA=[
 'app/src/main/java/ir/nahj/towhidkarbordi/CourseReminderScheduler.java',
 'app/src/main/java/ir/nahj/towhidkarbordi/PmmReminderClock.java',
]
NATIVE=['app/src/main/java/ir/nahj/towhidkarbordi/WisdomReminderScheduler.java',
        'app/src/main/java/ir/nahj/towhidkarbordi/WisdomReminderReceiver.java']
WEB=['app/src/main/assets/index.html','app/src/main/assets/pmm_offline_course.js']
ACTIVE_APP=WEB+NATIVE+['app/src/main/java/ir/nahj/towhidkarbordi/MainActivity.java']+NEW_JAVA

def git(cwd,*args):
    return subprocess.check_output(['git',*args],cwd=cwd)
def hashblob(content):
    return hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest()
def unchanged_source(cwd):
    if git(cwd,'rev-parse','HEAD').decode().strip()!=BASE_COMMIT:
        raise RuntimeError('Refusing unexpected HEAD (must be approved v118 main): '+BASE_COMMIT)
    if git(cwd,'status','--porcelain').strip():
        raise RuntimeError('Refusing to patch a dirty checkout; create a fresh branch first')
    for path,sha in ORIGINAL.items():
        b=(cwd/path).read_bytes()
        if hashblob(b)!=sha:
            raise RuntimeError('Unexpected original file: '+path)
    lock=json.loads((cwd/'design/owner-v118-main-app-lock.json').read_text())
    if lock.get('approved_app_files_count')!=180 or len(lock['files'])!=180:
        raise RuntimeError('Unexpected v118 lock')
    for path,sha in lock['files'].items():
        if hashblob((cwd/path).read_bytes())!=sha:
            raise RuntimeError('Baseline lock mismatch: '+path)
    for path in NEW_JAVA:
        if (cwd/path).exists():raise RuntimeError('Refusing to overwrite a new class: '+path)
    return lock

def transform_ci(ci):
    changes=[
     ('name: Verify owner-approved active v118 and preserve V117/V16/V10.4.9 historical references',
      'name: Verify owner-approved active v119 reminders and preserve V118/V117/V16/V10.4.9'),
     ('- name: Checkout active owner-approved v118 source',
      '- name: Checkout active owner-approved v119 reminder source'),
     ('- name: Check every active application file against v118 owner lock\n        run: python3 scripts/verify_owner_v118_lock.py',
      '- name: Check every active application file against v119 owner lock\n        run: python3 scripts/verify_owner_v119_lock.py'),
     ('      - name: Checkout historic owner-frozen v117 main',
      '      - name: Check reminder schedule and JS state across updates\n'
      '        run: |\n'
      '          javac -d "$RUNNER_TEMP/pmm-clock" app/src/main/java/ir/nahj/towhidkarbordi/PmmReminderClock.java scripts/TestReminderClock.java\n'
      '          java -cp "$RUNNER_TEMP/pmm-clock" TestReminderClock\n'
      '          node scripts/test_course_state_compat.js\n'
      '          bash scripts/test_native_compile.sh\n'
      '      - name: Checkout owner-approved v118 historical reference\n'
      '        uses: actions/checkout@v4\n'
      '        with:\n'
      f'          ref: {BASE_COMMIT}\n'
      '          path: preserved-v118\n'
      '      - name: Verify unchanged v118 reference\n'
      '        working-directory: preserved-v118\n'
      '        run: python3 scripts/verify_owner_v118_lock.py\n'
      '      - name: Checkout historic owner-frozen v117 main'),
    ]
    for before,after in changes:
        if ci.count(before)!=1:
            raise RuntimeError('CI anchor missing or duplicated: '+before[:90])
        ci=ci.replace(before,after,1)
    if '  verify-ui-lock:' not in ci:
        raise RuntimeError('Required GitHub check status removed')
    return ci

def verifier():
    return '''#!/usr/bin/env python3\n"""Owner-approved active v119 reminder source lock. Preserve all 182 app files."""\nimport hashlib,json,subprocess\nfrom pathlib import Path\nroot=Path(__file__).resolve().parents[1]\ndata=json.loads((root/'design/owner-v119-main-app-lock.json').read_text(encoding='utf-8'))\nexpected=data['files']\nassert len(expected)==data['approved_app_files_count']==182\ntracked={x.decode('utf-8') for x in subprocess.check_output(['git','ls-files','-z','--','app/'],cwd=root).split(b'\\0') if x}\nassert tracked==set(expected),('Owner lock set changed',sorted(tracked-set(expected)),sorted(set(expected)-tracked))\nfor path,want in sorted(expected.items()):\n b=(root/path).read_bytes()\n have=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\\0'+b).hexdigest()\n assert have==want,('Owner v119 lock violation',path,have,want)\nprint('PASS: 182 owner-approved v119 app Git blobs are frozen.')\n'''

def main(root):
    old=unchanged_source(root)
    # Prepare ALL outputs in memory before writing a single file.
    output={}
    for path in WEB+NATIVE+NEW_JAVA:
        output[path]=(PATCH/path).read_bytes()
    original_java=(root/'app/src/main/java/ir/nahj/towhidkarbordi/MainActivity.java').read_text(encoding='utf-8')
    output['app/src/main/java/ir/nahj/towhidkarbordi/MainActivity.java']=patch(original_java).encode('utf-8')
    ci=transform_ci((root/'.github/workflows/verify-layout-lock.yml').read_text(encoding='utf-8'))
    output['.github/workflows/verify-layout-lock.yml']=ci.encode('utf-8')
    newlock=dict(old)
    newlock.update({
      'schema':'owner-v119-active-main-git-blob-lock-v1',
      'approval':'Owner 2026-11-20 explicitly authorized persistent local wisdom and offline-course reminders. Owner accepted v118 preserved unchanged as historical reference.',
      'approved_version':'owner-v119-reminder-preview',
      'prior_owner_approval':BASE_COMMIT,
      'historical_owner_lock':'design/owner-v118-main-app-lock.json',
      'note':'No edits to market release, signing keys, app/build.gradle, original locked fonts, assets other than HTML/JS, old snapshots or tags. New course time 05:00-23:59 or end-of-day 00:00. Wisdom quiet 00:00-07:00. Requires Android notification consent.',
    })
    newlock['approved_app_files_count']=182
    newlock['files']={**old['files'],**{path:hashblob(output[path]) for path in ACTIVE_APP}}
    assert len(newlock['files'])==182
    old_changed=[p for p in old['files'] if newlock['files'][p]!=old['files'][p]]
    assert set(old_changed)==set(ACTIVE_APP)-set(NEW_JAVA),old_changed
    output['design/owner-v119-main-app-lock.json']=(json.dumps(newlock,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    output['scripts/verify_owner_v119_lock.py']=verifier().encode('utf-8')
    for path in ['scripts/TestReminderClock.java','scripts/test_native_compile.sh','scripts/test_course_state_compat.js']:
        output[path]=(PATCH/path).read_bytes()
    note=('''# Owner-approved v119 reminder implementation, awaiting full APK tests\n\n'
          'First-run notification consent: Android 13+ OS prompt, older Androids an explicit in-app dialog.\n'
          'Wisdom: wall-clock of initial consent, normalized to 07:00 for consent between 00:00 and 06:59, quiet-period notification suppression.\n'
          'Course: daily one/two or chosen weekly weekday, user-selected local time 05:00–23:59 plus 00:00 end-of-day, on-device and silent.\n'
          'After update/reboot/timezone reset both alarms, with independent PendingIntents and channels.\n'
          'App content and MP3s are never fetched by reminder receivers.\n'
          'No guarantee of exact-to-the-minute delivery because Android optimizes inexact alarms for battery.\n'
          'Historical v118 lock remains untouched. No official release, market APK or signing modifications.\n''').encode('utf-8')
    output['design/OWNER_V119_REMINDERS_FA.md']=note
    agents=root/'AGENTS.md'
    owner=root/'OWNER_LOCK.md'
    output['AGENTS.md']=(
      '# New owner-authorized v119 reminder branch — 2026-11-20\n'
      'Only owner-approved persistent Wisdom and course local reminders are changed.\n'
      'Active file lock: design/owner-v119-main-app-lock.json (182 app files).\n'
      'Historical v118 lock is preserved. No official release authorized.\n\n---\n\n'
    ).encode()+agents.read_bytes()
    output['OWNER_LOCK.md']=(
      '# قفل تأیید‌شده برای نسخه آزمایشی یادآورها — v119\n\n'
      'بر اساس دستور مالک در تاریخ ۲۰ نوامبر ۲۰۲۶، فقط یادآور تفأل و دوره آفلاین اصلاح شده‌اند.\n'
      'قفل جدید ۱۸۲ فایل در design/owner-v119-main-app-lock.json ثبت شده است.\n'
      'قفل تاریخی v118 و همه نسخه‌ها و امضاهای رسمی باید دست‌نخورده بمانند.\n\n---\n\n'
    ).encode()+owner.read_bytes()
    for rel in output:
        if rel not in ORIGINAL and (root/rel).exists() and rel.startswith(('design/owner-v119','scripts/verify_owner_v119','scripts/TestReminder','scripts/test_native_compile','scripts/test_course','app/src/main/java/ir/nahj/towhidkarbordi/CourseReminder','app/src/main/java/ir/nahj/towhidkarbordi/PmmReminder')):
            raise RuntimeError('Refusing to overwrite an existing new file: '+rel)
    for rel,content in output.items():
        p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(content)
    print('PASS: generated',len(output),'authorized file changes in new local working tree.')
    print('NEXT: git add only listed paths; run python3 scripts/verify_owner_v119_lock.py; verify CI and build debug APK. DO NOT push or merge without review.')

if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('usage: python3 scripts/apply_to_checkout.py /path/to/clean/v118-checkout')
    main(Path(sys.argv[1]).resolve())
