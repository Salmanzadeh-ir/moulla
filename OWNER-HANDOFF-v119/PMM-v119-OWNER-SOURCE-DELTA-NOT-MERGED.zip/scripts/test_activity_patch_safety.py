from pathlib import Path
import ast,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from patch_main_activity import patch
source=Path(__file__).with_name('patch_main_activity.py').read_text(encoding='utf-8')
module=ast.parse(source)
anchors=[]
for node in ast.walk(module):
 if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='replace_unique' and len(node.args)==4:
  if isinstance(node.args[1],ast.Constant) and isinstance(node.args[1].value,str): anchors.append(node.args[1].value)
assert len(anchors)==10, f'Expected ten explicit MainActivity anchors: {len(anchors)}'
# Every transformation is fail-closed; no approximate or global substitutions are authorized.
fixture='\n'.join(anchors)
modified=patch(fixture)
assert modified!=fixture
for token in ['setCourseReminderSchedule','clearCourseReminderSchedule','pendingCourseOpen','openCourseIfPending',
              'CourseReminderScheduler.initialize(this)','CourseReminderScheduler.sync(this)',
              'new android.app.AlertDialog.Builder(this)','initial_opt_in_local_clock']:
 assert token in modified,token
try:patch(fixture.replace(anchors[0],''))
except RuntimeError: pass
else: raise AssertionError('Fail-closed guard did not reject a missing anchor')
print('PASS: exactly ten scoped MainActivity modifications; unsafe/missing anchors rejected.')
