"""Apply owner-approved v119 reminder wiring to an EXACT v118 GitHub MainActivity.java source.
Refuses absent or duplicated anchors; no change to media, signing, UI layout, or other sources.
"""
from pathlib import Path
import sys

def replace_unique(source, old, new, label):
    count=source.count(old)
    if count!=1:
        raise RuntimeError(f'{label}: expected one anchor, found {count}; refusing unsafe patch')
    return source.replace(old,new,1)

def patch(s):
    s=replace_unique(s,'    private boolean pendingWisdomOpen = false;',
        '    private boolean pendingWisdomOpen = false;\n    private boolean pendingCourseOpen = false;',
        'pending native course')
    s=replace_unique(s,'status.put("minutesAfterFirstOpen", 5);',
        'status.put("clockBasis", "initial_opt_in_local_clock");\n                status.put("quietHours", "00:00-07:00");',
        'truthful wisdom schedule description')
    s=replace_unique(s, '''        /** A user-selected installed/photo-quote poster, including the approved online CDN. */''', '''        /** Schedule only an owner-approved, fully validated local course reminder. */
        @JavascriptInterface
        public void setCourseReminderSchedule(final String mode,final int weekday,final String time) {
            if (!PmmReminderClock.validCourseTime(time) ||
                !("daily1".equals(mode) || "daily2".equals(mode) ||
                  ("weekly".equals(mode) && weekday>=0 && weekday<=6))) return;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed() || web==null ||
                    !"file:///android_asset/index.html".equals(web.getUrl())) return;
                CourseReminderScheduler.setPlan(MainActivity.this,mode,weekday,time);
            });
        }

        @JavascriptInterface
        public void clearCourseReminderSchedule() {
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed() || web==null ||
                    !"file:///android_asset/index.html".equals(web.getUrl())) return;
                CourseReminderScheduler.clearPlan(MainActivity.this);
            });
        }

        /** A user-selected installed/photo-quote poster, including the approved online CDN. */''',
        'native bridge course setter')
    s=replace_unique(s,'''        WisdomReminderScheduler.initialize(this);
        pendingWisdomOpen = getIntent() != null &&
                getIntent().getBooleanExtra(WisdomReminderScheduler.EXTRA_OPEN_WISDOM, false);''', '''        WisdomReminderScheduler.initialize(this);
        CourseReminderScheduler.initialize(this);
        pendingWisdomOpen = getIntent() != null &&
                getIntent().getBooleanExtra(WisdomReminderScheduler.EXTRA_OPEN_WISDOM, false);
        pendingCourseOpen = getIntent() != null &&
                getIntent().getBooleanExtra(CourseReminderScheduler.EXTRA_OPEN_COURSE, false);''', 'initialization')
    s=replace_unique(s,'''                    openWisdomIfPending();
                }
            }
        });''', '''                    openWisdomIfPending();
                    openCourseIfPending();
                }
            }
        });''', 'WebView page-ready course')
    s=replace_unique(s,'''    private void requestReminderPermission() {
        if (!visibleToUser || isFinishing() || isDestroyed()) return;
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    REMINDER_PERMISSION_REQUEST);
        } else {
            // On Android 12 or earlier the system has no runtime permission.
            // A pre-granted Android 13+ install is also handled here.
            WisdomReminderScheduler.consent(this, true);
        }
    }''', '''    private void requestReminderPermission() {
        if (!visibleToUser || isFinishing() || isDestroyed()) return;
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // Android 13+: genuine system permission. It can only be granted by the user.
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    REMINDER_PERMISSION_REQUEST);
        } else {
            // Android 12 and earlier have no runtime POST_NOTIFICATIONS dialog.
            // A first-run, user-visible app consent dialog is required instead.
            // Also used for an Android 13+ app that already has system permission.
            new android.app.AlertDialog.Builder(this)
                .setTitle("اجازه اعلان‌های پای منبر مولا")
                .setMessage("مایلید یادآوری‌های بی‌صدای تفأل و زمان همراهی دوره آفلاین در نوار اعلان گوشی نمایش داده شوند؟ می‌توانید بعداً یادآور تفأل را خاموش کنید.")
                .setPositiveButton("اجازه می‌دهم", (dialog, which) -> {
                    WisdomReminderScheduler.consent(MainActivity.this, true);
                    CourseReminderScheduler.sync(MainActivity.this);
                })
                .setNegativeButton("فعلاً نه", (dialog, which) -> {
                    WisdomReminderScheduler.consent(MainActivity.this, false);
                    CourseReminderScheduler.sync(MainActivity.this);
                })
                .setCancelable(false)
                .show();
        }
    }''', 'initial consent dialog')
    s=replace_unique(s,'''            WisdomReminderScheduler.consent(this, granted);
            // If declined, never send a hidden background notification.''', '''            WisdomReminderScheduler.consent(this, granted);
            CourseReminderScheduler.sync(this);
            // A denial deactivates both reminder streams; no hidden background notice.''', 'OS permission answer')
    s=replace_unique(s,'''    @Override public void onNewIntent(Intent intent) {''', '''    private void openCourseIfPending() {
        if (!pendingCourseOpen || web == null ||
            !"file:///android_asset/index.html".equals(web.getUrl())) return;
        pendingCourseOpen=false;
        web.evaluateJavascript("(function(){if(window.PMM_OFFLINE_COURSE)" +
                "window.PMM_OFFLINE_COURSE.open();})()",null);
    }

    @Override public void onNewIntent(Intent intent) {''', 'notification tap opens matching course')
    s=replace_unique(s,'''        pendingWisdomOpen = intent != null &&
                intent.getBooleanExtra(WisdomReminderScheduler.EXTRA_OPEN_WISDOM, false);
        openWisdomIfPending();''', '''        pendingWisdomOpen = intent != null &&
                intent.getBooleanExtra(WisdomReminderScheduler.EXTRA_OPEN_WISDOM, false);
        pendingCourseOpen = intent != null &&
                intent.getBooleanExtra(CourseReminderScheduler.EXTRA_OPEN_COURSE, false);
        openWisdomIfPending();
        openCourseIfPending();''', 'onNewIntent course')
    s=replace_unique(s,'''        WisdomReminderScheduler.sync(this);
        // Reset only the visual × dismissals; keep stored audio progress.''', '''        WisdomReminderScheduler.sync(this);
        CourseReminderScheduler.sync(this);
        // Reset only the visual × dismissals; keep stored audio progress.''', 'onResume course sync')
    return s

if __name__=='__main__':
    if len(sys.argv)!=2: raise SystemExit('Usage: patch_main_activity.py path/to/MainActivity.java')
    path=Path(sys.argv[1]);s=path.read_text(encoding='utf-8');changed=patch(s)
    path.write_text(changed,encoding='utf-8')
    print('PASS: all MainActivity anchors patched exactly once')
